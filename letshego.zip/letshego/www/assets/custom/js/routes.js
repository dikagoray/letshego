 'use strict';

window.routes = [
	{
		path: '/',
		componentUrl: './partials/screens/splash.html'
	},
	{
		path: '/walkthrough',
		componentUrl: './partials/screens/walkthrough.html'
	},
	{
		path: '/home',
		componentUrl: './partials/screens/home.html'
	},
	{
		path: '/themes',
		componentUrl: './partials/themes.html'
	},
	{
		path: '/contacts',
		componentUrl: './partials/home.html',
		routes: [
			{
				path: '/police',
				componentUrl: './partials/contacts/police.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.police) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/health',
				componentUrl: './partials/contacts/health.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.health) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/emergency',
				componentUrl: './partials/contacts/emergency.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.emergency) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/local',
				componentUrl: './partials/contacts/local.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.local) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/mobile',
				componentUrl: './partials/contacts/mobile.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.mobile) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/roads',
				componentUrl: './partials/contacts/roads.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.roads) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/towing',
				componentUrl: './partials/contacts/towing.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.towing) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/security',
				componentUrl: './partials/contacts/security.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.security) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			},{
				path: '/auto',
				componentUrl: './partials/contacts/auto.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.auto) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['assets/vendor/alasql/alasql.min.js'], function() {
							app.preloader.hide();
							
							resolve();
							
						});
					}
				}
			}
		]
	},
	{
		path: '/more',
		componentUrl: './partials/more.html'
	},
	{
		path: '(.*)',
		componentUrl: './partials/screens/404.html'
	}
];